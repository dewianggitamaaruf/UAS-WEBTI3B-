<div class="card">
    <h2>Kontak</h2>
    <form action="">
        <label for="">Nama</label>
        <input type="text">
        <label for="">Email</label>
        <input type="text">
        <label for="">Pesan</label>
        <textarea name="" id="" cols="30" rows="10"></textarea>
    </form>
</div>