<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="alert alert-info">
                    Selamat Datang <strong><?= $user ?></strong>, Anda login menggunakan level <strong><?= $level; ?></strong>
                </div>
            </div>
        </div>
    </div>
</div>